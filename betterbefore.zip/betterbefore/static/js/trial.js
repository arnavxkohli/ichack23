// This fucntion retruns the product id 
function get_item_index(){
    return id
}





MyList.removeChild(items[id])